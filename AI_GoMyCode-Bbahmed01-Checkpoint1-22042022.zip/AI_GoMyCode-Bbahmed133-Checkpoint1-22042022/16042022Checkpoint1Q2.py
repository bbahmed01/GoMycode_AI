x = int(input("type a number: "))
result = 1
while(x>=2):
    print(x)
    result *= x
    x-=1

print(result)