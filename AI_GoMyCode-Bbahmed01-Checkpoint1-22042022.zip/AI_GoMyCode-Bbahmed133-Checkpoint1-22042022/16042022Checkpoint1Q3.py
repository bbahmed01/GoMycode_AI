dict = {}
x = int(input("enter a number: "))

for i in range(x+1) :
    ch = str(x)
    dict[ch]=x*x
print(dict)