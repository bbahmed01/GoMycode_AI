import numpy as np 

a1 = np.array([0, 1, 2])
a2 = np.array([2, 1, 0])

print(np.cov(a1, a2))