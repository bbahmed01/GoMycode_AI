import numpy as np
np_array = np.array([[0, 1], [2, 3], [4, 5]])
py_list = np_array.tolist()
print("numpy array : ",np_array)
print("pyhton list : ",py_list)